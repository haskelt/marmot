# salal
A simple system for building websites from templates and content
