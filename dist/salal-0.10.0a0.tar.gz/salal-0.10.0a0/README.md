Salal is a simple system for building websites from templates and content.

[About Salal](https://github.com/haskelt/salal/wiki/About-Salal)
[Installation](https://github.com/haskelt/salal/wiki/Installation)
